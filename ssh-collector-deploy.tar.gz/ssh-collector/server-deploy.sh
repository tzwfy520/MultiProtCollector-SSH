#!/bin/bash

# 服务器端部署脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查Docker是否安装
check_docker() {
    if ! command -v docker &> /dev/null; then
        log_info "安装Docker..."
        curl -fsSL https://get.docker.com -o get-docker.sh
        sudo sh get-docker.sh
        sudo usermod -aG docker $USER
        log_success "Docker安装完成"
    else
        log_info "Docker已安装"
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_info "安装Docker Compose..."
        sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
        log_success "Docker Compose安装完成"
    else
        log_info "Docker Compose已安装"
    fi
}

# 创建必要目录
create_directories() {
    log_info "创建必要目录..."
    mkdir -p data logs
    chmod 755 data logs
    log_success "目录创建完成"
}

# 配置环境变量
setup_env() {
    log_info "配置环境变量..."
    if [ ! -f .env ]; then
        cp .env.example .env
        log_info "请根据需要修改 .env 文件中的配置"
    fi
}

# 构建和启动服务
deploy_service() {
    log_info "构建和启动SSH采集器服务..."
    
    # 停止现有服务
    docker-compose down 2>/dev/null || true
    
    # 构建镜像
    docker-compose build --no-cache
    
    # 启动服务
    docker-compose up -d
    
    log_success "服务启动完成"
}

# 验证部署
verify_deployment() {
    log_info "验证部署结果..."
    
    # 等待服务启动
    sleep 10
    
    # 检查容器状态
    if docker-compose ps | grep -q "Up"; then
        log_success "容器运行正常"
    else
        log_error "容器启动失败"
        docker-compose logs
        exit 1
    fi
    
    # 检查健康状态
    local retries=5
    for i in $(seq 1 $retries); do
        if curl -f http://localhost:8000/health &>/dev/null; then
            log_success "服务健康检查通过"
            break
        else
            if [ $i -eq $retries ]; then
                log_error "服务健康检查失败"
                exit 1
            fi
            log_info "等待服务就绪... ($i/$retries)"
            sleep 5
        fi
    done
}

# 显示部署信息
show_deployment_info() {
    echo "========================================"
    log_success "SSH采集器部署完成！"
    echo "========================================"
    echo "服务地址: http://$(hostname -I | awk '{print $1}'):8000"
    echo "健康检查: http://$(hostname -I | awk '{print $1}'):8000/health"
    echo "========================================"
    echo "常用命令:"
    echo "  查看服务状态: docker-compose ps"
    echo "  查看日志: docker-compose logs -f"
    echo "  重启服务: docker-compose restart"
    echo "  停止服务: docker-compose down"
    echo "========================================"
}

# 主函数
main() {
    log_info "开始部署SSH采集器..."
    
    check_docker
    create_directories
    setup_env
    deploy_service
    verify_deployment
    show_deployment_info
    
    log_success "部署流程完成！"
}

# 执行主函数
main "$@"
