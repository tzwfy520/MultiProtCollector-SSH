"""
SSH采集器包
基于Python netmiko库的SSH设备采集器
"""

__version__ = "1.0.0"
__author__ = "SSH Collector Team"
__description__ = "基于netmiko的SSH设备采集器"